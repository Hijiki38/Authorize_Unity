﻿using System.Collections;
using System.Text;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Networking;

public class PwTransmitter : MonoBehaviour
{
    [SerializeField]
    Text txt;

    private const string URI = "https://script.google.com/macros/s/AKfycbwK013o9vK098Ny24rT-0hAmCkBmTdz72btBUjusRn7m4TPsOIj/exec"; //ここにWebアプリケーションとして公開時に発行されるURLを貼る
    private string pass = null;

    private void Start()
    {
        //StartCoroutine(Post());
    }

    public IEnumerator Post()
    {
        var jsonBody = $"{{ \"pass\" : \"{pass}\" }}";
        var request = new UnityWebRequest(URI, "POST");
        byte[] bodyRaw = Encoding.UTF8.GetBytes(jsonBody);
        request.uploadHandler = (UploadHandler)new UploadHandlerRaw(bodyRaw);
        request.downloadHandler = (DownloadHandler)new DownloadHandlerBuffer();
        request.SetRequestHeader("Content-Type", "application/json");

        yield return request.SendWebRequest();

        if (request.isHttpError || request.isNetworkError)
        {
            Debug.Log(request.error);
        }
        else
        {
            var result = request.downloadHandler.text;   
            var response = JsonUtility.FromJson<ResponseData>(result);
            //Debug.Log(response.message);   

            if (response.message.Equals("succeeded")) //スプレッドシートのパスワードと一致
            {
                txt.text = ("認証に成功しました！\nあなたのユーザNo.は" + response.userno + "です"); //response.usernoによってログを保存するファイル分ければ被験者ごとのログをとれそう
            }
            else
            {
                txt.text = ("認証に失敗しました．\n4桁のパスワードを再入力してください");
            }
        }
    }

    public void Authorize(string pw)
    {
        pass = pw;
        if(pass != null)
        {
            StartCoroutine(Post());
        }

    }

    [System.Serializable]
    public class PostData
    {
        public int point;
    }

    [System.Serializable]
    public class ResponseData
    {
        public string message;
        public int userno;
    }
}